# Deep Search

A single-file, ChatGPT-style chat app built in Claude.

## Features
- Streaming chat replies, saved chat history, chat export (Markdown)
- Personas and custom instructions, Fast / Balanced / Best quality picker
- Image and text-file attachments, voice dictation
- Your own knowledge base with local search (stored in the browser)
- Charts, code preview, light and dark themes

## Files
- `index.html` — the whole app (HTML, CSS and JavaScript, no build step)

## Important
The AI replies come from Claude's built-in runtime (`claude.use("sample")`), which only exists
when the page is opened as a Claude artifact. If you host this file on GitHub Pages or any other
site, the interface loads but chat replies will not work until you connect your own AI backend
(for example, a small server that calls an AI API with your own key).

Chats and knowledge-base documents live in each visitor's browser (localStorage) and are not
part of this repository.
